import os
import sqlite3
import uuid
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import (
    Flask, abort, flash, jsonify, redirect, render_template,
    request, send_from_directory, session, url_for
)
from werkzeug.utils import secure_filename

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "documents.db"
UPLOAD_DIR = APP_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "development-only-change-me")
app.config["MAX_CONTENT_LENGTH"] = 15 * 1024 * 1024  # 15 MB per upload

ALLOWED_EXTENSIONS = {
    "pdf", "doc", "docx", "txt", "ppt", "pptx",
    "xls", "xlsx", "csv", "png", "jpg", "jpeg"
}


def db():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS folders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            owner_id INTEGER NOT NULL,
            owner_name TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(owner_id, name)
        );
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL UNIQUE,
            folder_id INTEGER NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
            uploader_id INTEGER NOT NULL,
            uploader_name TEXT NOT NULL,
            uploader_role TEXT NOT NULL CHECK(uploader_role IN ('faculty','student')),
            visibility TEXT NOT NULL DEFAULT 'shared'
                CHECK(visibility IN ('shared','private')),
            uploaded_at TEXT NOT NULL,
            size_bytes INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_docs_folder ON documents(folder_id);
        CREATE INDEX IF NOT EXISTS idx_docs_visibility ON documents(visibility);
        """)


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id") or session.get("role") not in ("faculty", "student"):
            flash("Sign in as a student or faculty member first.", "error")
            return redirect(url_for("home"))
        return fn(*args, **kwargs)
    return wrapper


def allowed_file(name):
    return "." in name and name.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def can_access_document(row):
    user_id = int(session["user_id"])
    return (
        row["visibility"] == "shared"
        or row["uploader_id"] == user_id
        or row["folder_owner_id"] == user_id
    )


@app.route("/")
def home():
    if not session.get("user_id"):
        return render_template("index.html", user=None, role=None, folders=[], documents=[])
    user_id = int(session["user_id"])
    with db() as con:
        folders = con.execute("""
            SELECT f.*, COUNT(d.id) AS document_count
            FROM folders f LEFT JOIN documents d ON d.folder_id=f.id
            WHERE f.owner_id=?
            GROUP BY f.id ORDER BY f.name
        """, (user_id,)).fetchall()
        # Own docs plus shared docs in folders that the user can see.
        documents = con.execute("""
            SELECT d.*, f.name AS folder_name, f.owner_id AS folder_owner_id
            FROM documents d JOIN folders f ON f.id=d.folder_id
            WHERE d.uploader_id=? OR d.visibility='shared'
            ORDER BY d.uploaded_at DESC
        """, (user_id,)).fetchall()
    return render_template("index.html", user=session.get("user_name"),
                           role=session.get("role"), folders=folders, documents=documents)


@app.post("/demo-login")
def demo_login():
    # Demo-only login. Replace with the project's real authentication.
    name = request.form.get("user_name", "").strip()
    role = request.form.get("role", "").strip()
    if not name or role not in ("faculty", "student"):
        flash("Enter a name and select Student or Faculty.", "error")
    else:
        # Stable demo ID by name+role in this standalone module.
        import hashlib
        identity = hashlib.sha256((role + ":" + name.casefold()).encode()).hexdigest()
        user_id = int(identity[:12], 16)
        session["user_id"] = user_id
        session["user_name"] = name[:80]
        session["role"] = role
        flash(f"Signed in as {name} ({role}).", "success")
    return redirect(url_for("home"))


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.post("/folders")
@login_required
def create_folder():
    name = request.form.get("name", "").strip()
    if not name or len(name) > 100:
        flash("Folder name is required (up to 100 characters).", "error")
        return redirect(url_for("home"))
    try:
        with db() as con:
            con.execute("""
                INSERT INTO folders(name, owner_id, owner_name, created_at)
                VALUES(?,?,?,?)
            """, (name, int(session["user_id"]), session["user_name"], datetime.now().isoformat(timespec="seconds")))
        flash("Folder created.", "success")
    except sqlite3.IntegrityError:
        flash("You already have a folder with that name.", "error")
    return redirect(url_for("home"))


@app.post("/upload")
@login_required
def upload():
    file = request.files.get("file")
    if not file or not file.filename:
        flash("Choose a document to upload.", "error")
        return redirect(url_for("home"))
    original_name = secure_filename(file.filename)
    if not original_name or not allowed_file(original_name):
        flash("File type is not allowed.", "error")
        return redirect(url_for("home"))

    try:
        folder_id = int(request.form.get("folder_id", ""))
    except ValueError:
        flash("Choose a destination folder.", "error")
        return redirect(url_for("home"))

    visibility = request.form.get("visibility", "shared")
    if visibility not in ("shared", "private"):
        visibility = "shared"

    with db() as con:
        folder = con.execute("""
            SELECT id FROM folders WHERE id=? AND owner_id=?
        """, (folder_id, int(session["user_id"]))).fetchone()
        if not folder:
            flash("Upload only into a folder you own.", "error")
            return redirect(url_for("home"))

        stored_name = uuid.uuid4().hex + "_" + original_name
        destination = UPLOAD_DIR / stored_name
        try:
            file.save(destination)
            size_bytes = destination.stat().st_size
            con.execute("""
                INSERT INTO documents(
                    original_name, stored_name, folder_id,
                    uploader_id, uploader_name, uploader_role,
                    visibility, uploaded_at, size_bytes
                ) VALUES(?,?,?,?,?,?,?,?,?)
            """, (
                original_name, stored_name, folder_id,
                int(session["user_id"]), session["user_name"],
                session["role"], visibility,
                datetime.now().isoformat(timespec="seconds"), size_bytes
            ))
        except Exception:
            if destination.exists():
                destination.unlink()
            raise

    flash("Document uploaded successfully.", "success")
    return redirect(url_for("home"))


@app.get("/download/<int:document_id>")
@login_required
def download(document_id):
    with db() as con:
        row = con.execute("""
            SELECT d.*, f.owner_id AS folder_owner_id
            FROM documents d JOIN folders f ON f.id=d.folder_id
            WHERE d.id=?
        """, (document_id,)).fetchone()
    if not row:
        abort(404)
    if not can_access_document(row):
        abort(403)
    if not (UPLOAD_DIR / row["stored_name"]).is_file():
        abort(404, "File is missing from storage.")
    return send_from_directory(
        str(UPLOAD_DIR), row["stored_name"],
        as_attachment=True, download_name=row["original_name"]
    )


@app.post("/documents/<int:document_id>/delete")
@login_required
def delete_document(document_id):
    with db() as con:
        row = con.execute("""
            SELECT d.*, f.owner_id AS folder_owner_id
            FROM documents d JOIN folders f ON f.id=d.folder_id
            WHERE d.id=?
        """, (document_id,)).fetchone()
        if not row:
            flash("Document not found.", "error")
            return redirect(url_for("home"))
        if row["uploader_id"] != int(session["user_id"]) and row["folder_owner_id"] != int(session["user_id"]):
            flash("You can delete only your own document or a document in your own folder.", "error")
            return redirect(url_for("home"))
        con.execute("DELETE FROM documents WHERE id=?", (document_id,))
    path = UPLOAD_DIR / row["stored_name"]
    if path.is_file():
        path.unlink()
    flash("Document deleted.", "success")
    return redirect(url_for("home"))


@app.post("/folders/<int:folder_id>/delete")
@login_required
def delete_folder(folder_id):
    with db() as con:
        folder = con.execute("SELECT * FROM folders WHERE id=?", (folder_id,)).fetchone()
        if not folder:
            flash("Folder not found.", "error")
            return redirect(url_for("home"))
        if folder["owner_id"] != int(session["user_id"]):
            flash("You can delete only your own folders.", "error")
            return redirect(url_for("home"))
        rows = con.execute("SELECT stored_name FROM documents WHERE folder_id=?", (folder_id,)).fetchall()
        con.execute("DELETE FROM folders WHERE id=?", (folder_id,))
    for row in rows:
        path = UPLOAD_DIR / row["stored_name"]
        if path.is_file():
            path.unlink()
    flash("Folder and its documents deleted.", "success")
    return redirect(url_for("home"))


@app.get("/api/folders")
@login_required
def api_folders():
    with db() as con:
        rows = con.execute("""
            SELECT id, name, created_at FROM folders WHERE owner_id=? ORDER BY name
        """, (int(session["user_id"]),)).fetchall()
    return jsonify([dict(r) for r in rows])


@app.get("/api/documents")
@login_required
def api_documents():
    with db() as con:
        rows = con.execute("""
            SELECT d.id, d.original_name, d.folder_id, f.name AS folder_name,
                   d.uploader_name, d.uploader_role, d.visibility,
                   d.uploaded_at, d.size_bytes
            FROM documents d JOIN folders f ON f.id=d.folder_id
            WHERE d.uploader_id=? OR d.visibility='shared'
            ORDER BY d.uploaded_at DESC
        """, (int(session["user_id"]),)).fetchall()
    return jsonify([dict(r) for r in rows])


@app.errorhandler(413)
def too_large(_error):
    flash("File exceeds the 15 MB limit.", "error")
    return redirect(url_for("home"))


if __name__ == "__main__":
    init_db()
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1", port=5002)
