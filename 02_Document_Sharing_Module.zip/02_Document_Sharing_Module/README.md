# Module 2 — Student and Faculty Document Sharing

Standalone Flask module with a responsive web frontend and SQLite database.

## Features
- Student and faculty can create folders and upload documents.
- Folders are user-owned and can be named by subject, semester, course, etc.
- Documents can be marked shared or private.
- Shared documents can be downloaded by signed-in users.
- Private documents can be downloaded only by the uploader or owner of the folder.
- File extension allowlist and 15 MB upload limit.
- Document metadata is stored in SQLite; file bytes are stored under `uploads/`.

## Run on Windows
```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5002

## Demo login
Use the page's demo sign-in with role Student or Faculty. The demo identity uses a stable ID derived from name+role so the same demo identity can see its folders after signing out and in again.

## Integration notes
- Remove `/demo-login` and connect `login_required` to the existing OSDBMS authentication/session.
- The current implementation uses local disk storage. For production use private object storage, malware scanning, content-based file validation, CSRF protection, rate limits and a production secret key.
- Shared files are visible to any signed-in student or faculty user. Change `can_access_document` and list queries if your requirements call for course/section-based sharing.
- Folders are one level deep; nested folders are not included.
