# CampusSync — Appointment Email Notification Only

This package contains the CampusSync project with the appointment email feature, without the new chat/chatbot feature.

## What it does
When a student books an appointment, CampusSync attempts to email the selected faculty member using the email address stored in the users table. Booking still succeeds if SMTP is not configured or the email provider is temporarily unavailable.

## Run
1. Extract the ZIP and open the `CampusSync_Email_Only` folder in VS Code.
2. Open a terminal and run:
   ```powershell
   cd backend
   python server.py
   ```
3. Open `http://127.0.0.1:8000` in your browser.

## Enable real email (Gmail SMTP)
1. Copy `backend/.env.example` to `backend/.env`.
2. Set `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=587`, `SMTP_USER=your-gmail-address`, `SMTP_PASSWORD=your-16-character-google-app-password`, and `SMTP_FROM=your-gmail-address`. Keep `SMTP_USE_TLS=true`.
3. Use a Google App Password (not your normal Gmail password). Google App Passwords require 2-Step Verification.
4. Restart `python server.py` and book a test appointment. Check the faculty email inbox and spam folder.

The recipient address is taken from the faculty account in the CampusSync database. Do not share your `.env` file or commit it to source control.
