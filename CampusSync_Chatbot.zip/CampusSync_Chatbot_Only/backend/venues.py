import sqlite3
from database import get_connection
from users import is_admin

ACTIVE = "('Pending', 'Accepted', 'Rescheduled')"


def venue_problem(con, venue_id, day, time_slot, ignore_id=None):
    """Return a reason the venue cannot be used at this day/time, or None if it is free."""
    venue = con.execute("SELECT name FROM venues WHERE venue_id=?", (venue_id,)).fetchone()
    if venue is None:
        return "Venue not found"

    # A room that has a scheduled class is not available for meetings.
    if con.execute("""
        SELECT 1 FROM timetable WHERE room=? AND day=? AND time_slot=?
    """, (venue["name"], day, time_slot)).fetchone():
        return venue["name"] + " has a class at this time"

    if con.execute("""
        SELECT 1 FROM appointments
        WHERE venue_id=? AND day=? AND time_slot=?
        AND status IN """ + ACTIVE + """
        AND appointment_id IS NOT ?
    """, (venue_id, day, time_slot, ignore_id)).fetchone():
        return venue["name"] + " is already booked at this time"

    return None


def free_venues(con, day, time_slot, ignore_id=None):
    rows = con.execute(
        "SELECT venue_id, name, location, capacity FROM venues ORDER BY name"
    ).fetchall()
    return [dict(r) for r in rows
            if venue_problem(con, r["venue_id"], day, time_slot, ignore_id) is None]


def resolve_venue(con, day, time_slot, preferred=None, strict=False, ignore_id=None):
    """Choose the venue for a meeting. Returns (venue_id, error_message).

    strict=True  -> the caller explicitly chose `preferred`; it must be free.
    strict=False -> try `preferred` first, else first-fit: the first free venue.
    """
    if preferred not in (None, ""):
        try:
            preferred = int(preferred)
        except (TypeError, ValueError):
            return None, "Invalid venue"
        problem = venue_problem(con, preferred, day, time_slot, ignore_id)
        if problem is None:
            return preferred, None
        if strict:
            return None, problem

    free = free_venues(con, day, time_slot, ignore_id)
    if not free:
        return None, "No meeting venue is free at this time"
    return free[0]["venue_id"], None


def get_venues(params=None):
    con = get_connection()
    rows = con.execute(
        "SELECT venue_id, name, location, capacity FROM venues ORDER BY name"
    ).fetchall()
    con.close()
    return [dict(r) for r in rows]


def get_available_venues(params):
    day, slot = params.get("day"), params.get("time_slot")
    if not day or not slot:
        return {"success": False, "message": "day and time_slot are required"}
    con = get_connection()
    try:
        return {"success": True, "venues": free_venues(con, day, slot)}
    finally:
        con.close()


def add_venue(data):
    if not is_admin(data.get("admin_id")):
        return {"success": False, "message": "Only admin can manage venues"}

    name = (data.get("name") or "").strip()
    location = (data.get("location") or "").strip()
    try:
        capacity = int(data.get("capacity") or 1)
    except (TypeError, ValueError):
        capacity = 0

    if not name or capacity < 1:
        return {"success": False, "message": "Venue name and a capacity of at least 1 are required"}

    con = get_connection()
    try:
        con.execute("INSERT INTO venues(name, location, capacity) VALUES(?,?,?)",
                    (name, location, capacity))
        con.commit()
        return {"success": True, "message": "Venue added"}
    except sqlite3.IntegrityError:
        return {"success": False, "message": "A venue with this name already exists"}
    finally:
        con.close()


def delete_venue(data):
    if not is_admin(data.get("admin_id")):
        return {"success": False, "message": "Only admin can manage venues"}

    con = get_connection()
    try:
        if con.execute("""
            SELECT 1 FROM appointments WHERE venue_id=? AND status IN """ + ACTIVE,
                       (data.get("venue_id"),)).fetchone():
            return {"success": False,
                    "message": "Venue has active meetings. Cancel or move them first"}

        # Past/cancelled meetings keep their history without the venue link.
        con.execute("UPDATE appointments SET venue_id=NULL WHERE venue_id=?", (data.get("venue_id"),))
        cur = con.execute("DELETE FROM venues WHERE venue_id=?", (data.get("venue_id"),))
        con.commit()
        if not cur.rowcount:
            return {"success": False, "message": "Venue not found"}
        return {"success": True, "message": "Venue removed"}
    finally:
        con.close()
