"""Student/faculty messaging and a small rule-based CampusSync FAQ assistant."""
import re
from database import get_connection
from notifications import notify

MAX_MESSAGE = 2000


def _user(con, user_id):
    try:
        uid = int(user_id)
    except (TypeError, ValueError):
        return None
    return con.execute("SELECT user_id, name, email, role FROM users WHERE user_id=?", (uid,)).fetchone()


def _valid_pair(a, b):
    return a and b and {a["role"], b["role"]} == {"Student", "Faculty"} and a["user_id"] != b["user_id"]


def get_chat_contacts(params):
    user_id = params.get("user_id")
    con = get_connection()
    try:
        me = _user(con, user_id)
        if not me or me["role"] not in ("Student", "Faculty"):
            return {"success": False, "message": "A student or faculty account is required"}

        if me["role"] == "Student":
            rows = con.execute("""
                SELECT u.user_id, u.name, u.email,
                    (SELECT message FROM chat_messages m
                     WHERE (m.sender_id=u.user_id AND m.recipient_id=?)
                        OR (m.sender_id=? AND m.recipient_id=u.user_id)
                     ORDER BY m.message_id DESC LIMIT 1) AS last_message,
                    (SELECT COUNT(*) FROM chat_messages m
                     WHERE m.sender_id=u.user_id AND m.recipient_id=? AND m.is_read=0) AS unread
                FROM users u WHERE u.role='Faculty' ORDER BY u.name
            """, (me["user_id"], me["user_id"], me["user_id"])).fetchall()
        else:
            rows = con.execute("""
                SELECT u.user_id, u.name, u.email,
                    (SELECT message FROM chat_messages m
                     WHERE (m.sender_id=u.user_id AND m.recipient_id=?)
                        OR (m.sender_id=? AND m.recipient_id=u.user_id)
                     ORDER BY m.message_id DESC LIMIT 1) AS last_message,
                    (SELECT COUNT(*) FROM chat_messages m
                     WHERE m.sender_id=u.user_id AND m.recipient_id=? AND m.is_read=0) AS unread
                FROM users u
                WHERE u.role='Student' AND (
                    EXISTS (SELECT 1 FROM appointments a WHERE a.student_id=u.user_id AND a.faculty_id=?)
                    OR EXISTS (SELECT 1 FROM chat_messages m WHERE
                        (m.sender_id=u.user_id AND m.recipient_id=?) OR
                        (m.sender_id=? AND m.recipient_id=u.user_id))
                ) ORDER BY u.name
            """, (me["user_id"], me["user_id"], me["user_id"], me["user_id"], me["user_id"], me["user_id"])).fetchall()
        return {"success": True, "contacts": [dict(r) for r in rows]}
    finally:
        con.close()


def get_chat_messages(params):
    user_id, other_id = params.get("user_id"), params.get("other_user_id")
    con = get_connection()
    try:
        me, other = _user(con, user_id), _user(con, other_id)
        if not _valid_pair(me, other):
            return {"success": False, "message": "Choose a valid student/faculty conversation"}
        con.execute("UPDATE chat_messages SET is_read=1 WHERE sender_id=? AND recipient_id=? AND is_read=0",
                    (other["user_id"], me["user_id"]))
        rows = con.execute("""
            SELECT message_id, sender_id, recipient_id, message, created_at
            FROM chat_messages
            WHERE (sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?)
            ORDER BY message_id ASC LIMIT 300
        """, (me["user_id"], other["user_id"], other["user_id"], me["user_id"])).fetchall()
        con.commit()
        return {"success": True, "messages": [dict(r) for r in rows], "contact": {"user_id": other["user_id"], "name": other["name"], "role": other["role"]}}
    finally:
        con.close()


def send_chat_message(data):
    user_id, other_id = data.get("user_id"), data.get("recipient_id")
    message = (data.get("message") or "").strip()
    if not message:
        return {"success": False, "message": "Write a message first"}
    if len(message) > MAX_MESSAGE:
        return {"success": False, "message": f"Messages must be {MAX_MESSAGE} characters or fewer"}

    con = get_connection()
    try:
        me, other = _user(con, user_id), _user(con, other_id)
        if not _valid_pair(me, other):
            return {"success": False, "message": "Only students and faculty can message each other"}
        cur = con.execute("INSERT INTO chat_messages(sender_id, recipient_id, message) VALUES(?,?,?)",
                          (me["user_id"], other["user_id"], message))
        notify(con, other["user_id"], "chat", f"New message from {me['name']}")
        con.commit()
        return {"success": True, "message": "Message sent", "message_id": cur.lastrowid}
    finally:
        con.close()


def chatbot_reply(data):
    """Simple local FAQ bot; no external AI service or API key is required."""
    question = (data.get("message") or "").strip()
    if not question:
        return {"success": False, "message": "Type a question for the CampusSync assistant"}
    if len(question) > 1000:
        return {"success": False, "message": "Please keep your question under 1000 characters"}
    q = question.lower()
    if any(k in q for k in ("book", "appointment", "meet", "meeting")):
        answer = "To request a meeting, open Dashboard, choose a faculty member and an available day/time, enter your topic, then select Request. The faculty member receives an in-app notification and, when email is configured, an email."
    elif any(k in q for k in ("accept", "reject", "status", "pending", "reschedule", "cancel")):
        answer = "Open Dashboard to check your appointment status. Students can request a reschedule or cancel an active booking. Faculty can accept, reject, or reschedule requests."
    elif any(k in q for k in ("message", "chat", "contact", "faculty", "teacher", "professor")):
        answer = "Open Chat, choose a faculty member (or student if you are faculty), and send a message. The recipient will see an in-app notification when they next use CampusSync."
    elif any(k in q for k in ("document", "notes", "pdf", "download", "upload", "assignment")):
        answer = "Open Documents to browse and download shared academic files. Faculty and admins can upload documents from that page."
    elif any(k in q for k in ("calendar", "availability", "free slot", "time")):
        answer = "Open Calendar to view the weekly schedule. Students can choose a faculty member to inspect availability and select a free slot to start booking."
    elif any(k in q for k in ("email", "mail", "notification")):
        answer = "CampusSync saves in-app notifications automatically. Appointment emails require mail settings in backend/.env; see EMAIL_AND_CHAT_SETUP.md for configuration."
    elif any(k in q for k in ("hello", "hi", "hey", "help")):
        answer = "Hi! I'm the CampusSync assistant. Ask me about appointments, faculty chat, notifications, documents, or the calendar. For a personal question, open Chat and message your faculty member."
    else:
        answer = "I can help with appointments, rescheduling, faculty/student chat, notifications, documents, and the calendar. Try asking about one of those topics, or open Chat to message a faculty member directly."
    return {"success": True, "reply": answer}
