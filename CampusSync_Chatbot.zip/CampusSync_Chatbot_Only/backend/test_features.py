"""Checks for venues, documents and faculty invitations. Run: python3 test_features.py"""
import base64, os, tempfile
tmp = tempfile.mkdtemp()
os.environ["CAMPUS_DB"] = os.path.join(tmp, "t.db")
os.environ["CAMPUS_UPLOADS"] = os.path.join(tmp, "up")
for k in ("RESEND_API_KEY", "SMTP_HOST", "APP_BASE_URL"):
    os.environ.pop(k, None)

from database import init_db, get_connection
init_db()
from appointments import book_appointment, respond_appointment, reschedule_appointment, cancel_appointment, get_appointments
from reschedule import request_reschedule, respond_reschedule
from venues import get_venues, get_available_venues, add_venue, delete_venue
from documents import upload_document, get_documents, get_download, delete_document
from invites import create_invitation, list_invitations, revoke_invitation, check_invitation, accept_invitation
from users import delete_user
from auth import login
from notifications import get_notifications

ok = lambda r: r["success"]
A, F, S = 1, 2, 3          # admin, faculty (Dr. Sharma), student
b64 = lambda b: base64.b64encode(b).decode()

# ---------- venues: faculty chooses the venue when confirming ----------
venues = get_venues()
assert len(venues) == 5
v1, v2 = venues[0]["venue_id"], venues[1]["venue_id"]

assert ok(book_appointment({"student_id": S, "faculty_id": F, "day": "Mon", "time_slot": "14:00", "topic": "a"}))
assert ok(book_appointment({"student_id": S, "faculty_id": 4, "day": "Mon", "time_slot": "14:00", "topic": "b"}))
assert all(a["venue_id"] is None for a in get_appointments({}))                 # student request carries no venue
# confirming without a venue is refused; nothing changes
r = respond_appointment({"appointment_id": 1, "faculty_id": F, "action": "Accepted"})
assert not ok(r) and "venue" in r["message"].lower() and get_appointments({})[-1]["status"] == "Pending", r
assert ok(respond_appointment({"appointment_id": 1, "faculty_id": F, "action": "Accepted", "venue_id": v1}))
# the student is notified with the faculty's venue
msgs = [n["message"] for n in get_notifications({"user_id": S})["notifications"]]
assert any("accepted your meeting on Mon 14:00 at Faculty Cabin" in m for m in msgs), msgs
assert [a for a in get_appointments({}) if a["appointment_id"] == 1][0]["venue"] == "Faculty Cabin"
# another faculty cannot confirm into the same venue at the same time, but can pick a free one
r = respond_appointment({"appointment_id": 2, "faculty_id": 4, "action": "Accepted", "venue_id": v1})
assert not ok(r) and "already booked" in r["message"], r
assert v1 not in [v["venue_id"] for v in get_available_venues({"day": "Mon", "time_slot": "14:00"})["venues"]]
assert ok(respond_appointment({"appointment_id": 2, "faculty_id": 4, "action": "Accepted", "venue_id": v2}))
# another faculty cannot answer someone else's request; rejecting needs no venue
assert ok(book_appointment({"student_id": S, "faculty_id": F, "day": "Wed", "time_slot": "11:00", "topic": "c"}))
assert not ok(respond_appointment({"appointment_id": 3, "faculty_id": 4, "action": "Rejected"}))
assert ok(respond_appointment({"appointment_id": 3, "faculty_id": F, "action": "Rejected"}))
# a room that has a class is not a free venue
con = get_connection(); con.execute("INSERT INTO venues(name) VALUES('204')"); con.commit(); con.close()
assert "204" not in [v["name"] for v in get_available_venues({"day": "Mon", "time_slot": "09:00"})["venues"]]
assert "204" in [v["name"] for v in get_available_venues({"day": "Mon", "time_slot": "10:00"})["venues"]]
# faculty reschedule keeps the venue; cancelling frees it
assert ok(reschedule_appointment({"appointment_id": 1, "faculty_id": F, "day": "Tue", "time_slot": "14:00"}))
assert [a for a in get_appointments({}) if a["appointment_id"] == 1][0]["venue_id"] == v1
assert ok(cancel_appointment({"appointment_id": 1, "user_id": S}))
assert v1 in [v["venue_id"] for v in get_available_venues({"day": "Tue", "time_slot": "14:00"})["venues"]]
# pending requests (no venue) can still be rescheduled by the student
assert ok(book_appointment({"student_id": S, "faculty_id": F, "day": "Fri", "time_slot": "09:00", "topic": "d"}))
assert ok(request_reschedule({"appointment_id": 4, "student_id": S, "day": "Fri", "time_slot": "10:00"}))
assert ok(respond_reschedule({"request_id": 1, "faculty_id": F, "action": "Approved"}))
assert [a for a in get_appointments({}) if a["appointment_id"] == 4][0]["venue_id"] is None
# no free venue at all -> clear error
auto_v = v2
r = delete_venue({"admin_id": A, "venue_id": auto_v}); assert not ok(r) and "active meetings" in r["message"], r
con = get_connection(); con.execute("DELETE FROM venues WHERE venue_id NOT IN (?, ?)", (auto_v, v1)); con.commit(); con.close()
assert ok(book_appointment({"student_id": S, "faculty_id": F, "day": "Thu", "time_slot": "15:00", "topic": "p"}))
assert ok(book_appointment({"student_id": S, "faculty_id": 4, "day": "Thu", "time_slot": "15:00", "topic": "q"}))
assert ok(respond_appointment({"appointment_id": 5, "faculty_id": F, "action": "Accepted", "venue_id": v1}))
assert ok(respond_appointment({"appointment_id": 6, "faculty_id": 4, "action": "Accepted", "venue_id": v2}))
assert get_available_venues({"day": "Thu", "time_slot": "15:00"})["venues"] == []
# admin venue management
assert not ok(add_venue({"admin_id": S, "name": "X"}))
assert ok(add_venue({"admin_id": A, "name": "Lab Annex", "capacity": 4}))
assert not ok(add_venue({"admin_id": A, "name": "Lab Annex"}))
vid = [v for v in get_venues() if v["name"] == "Lab Annex"][0]["venue_id"]
assert ok(delete_venue({"admin_id": A, "venue_id": vid}))

# ---------- documents ----------
pdf = b"%PDF-1.4 hello"
assert not ok(upload_document({"user_id": S, "title": "t", "filename": "a.pdf", "data": b64(pdf)}))      # students cannot upload
assert not ok(upload_document({"user_id": F, "title": "t", "filename": "evil.exe", "data": b64(pdf)}))   # type blocked
assert not ok(upload_document({"user_id": F, "title": "t", "filename": "a.pdf", "data": "!!notbase64"}))
assert not ok(upload_document({"user_id": F, "title": "", "filename": "a.pdf", "data": b64(pdf)}))
assert not ok(upload_document({"user_id": F, "title": "big", "filename": "a.pdf", "data": b64(b"x" * (10 * 1024 * 1024 + 1))}))
r = upload_document({"user_id": F, "title": "DBMS Unit 1", "subject": "DBMS", "filename": "../../etc/pass wd.pdf", "data": b64(pdf)})
assert ok(r), r
docs = get_documents({"user_id": S})["documents"]
assert len(docs) == 1 and docs[0]["filename"] == "pass wd.pdf" and docs[0]["uploader"] == "Dr. Sharma"
assert os.listdir(os.environ["CAMPUS_UPLOADS"])[0].endswith(".pdf")
assert get_download({"user_id": S, "document_id": docs[0]["document_id"]})[2] == pdf
assert get_download({"user_id": 999, "document_id": docs[0]["document_id"]}) is None
assert get_documents({"user_id": S, "q": "dbms"})["documents"] and not get_documents({"user_id": S, "q": "zzz"})["documents"]
kinds = [n["kind"] for n in get_notifications({"user_id": S})["notifications"]]
assert "document" in kinds                                                    # students are notified
assert not ok(delete_document({"user_id": 4, "document_id": docs[0]["document_id"]}))   # other faculty cannot delete
assert ok(delete_document({"user_id": F, "document_id": docs[0]["document_id"]}))
assert os.listdir(os.environ["CAMPUS_UPLOADS"]) == []
# deleting an uploader removes their documents and files
con = get_connection(); con.execute("DELETE FROM appointments WHERE faculty_id=4"); con.commit(); con.close()
assert ok(upload_document({"user_id": 4, "title": "x", "filename": "n.txt", "data": b64(b"hi")}))
assert len(os.listdir(os.environ["CAMPUS_UPLOADS"])) == 1
r = delete_user({"admin_id": A, "user_id": 4}); assert ok(r), r
assert os.listdir(os.environ["CAMPUS_UPLOADS"]) == [] and get_documents({"user_id": S})["documents"] == []

# ---------- invitations ----------
assert not ok(create_invitation({"admin_id": S, "email": "n@x.com"}))
assert not ok(create_invitation({"admin_id": A, "email": "not-an-email"}))
assert not ok(create_invitation({"admin_id": A, "email": "faculty@campussync.com"}))     # already registered
r = create_invitation({"admin_id": A, "email": "New.Prof@Uni.edu", "name": "Prof New", "_base_url": "http://h"})
assert ok(r) and r["email_sent"] is False and r["invite_link"].startswith("http://h/?invite="), r
token = r["invite_link"].split("=")[1]
con = get_connection()
assert token not in str(con.execute("SELECT * FROM invitations").fetchall()[0][:])      # raw token never stored
con.close()
assert check_invitation({"token": token})["email"] == "new.prof@uni.edu"
assert not ok(check_invitation({"token": "wrong"}))
assert not ok(accept_invitation({"token": token, "name": "P", "password": "short"}))
r2 = create_invitation({"admin_id": A, "email": "new.prof@uni.edu", "_base_url": "http://h"})   # re-invite replaces old link
assert not ok(check_invitation({"token": token}))
token2 = r2["invite_link"].split("=")[1]
assert ok(accept_invitation({"token": token2, "name": "Prof New", "password": "strongpass1"}))
assert not ok(accept_invitation({"token": token2, "name": "Prof New", "password": "strongpass1"}))   # single use
assert login({"email": "new.prof@uni.edu", "password": "strongpass1"})["role"] == "Faculty"
assert [i["state"] for i in list_invitations({"admin_id": A})["invitations"]] == ["Accepted"]
# expiry + revoke
r3 = create_invitation({"admin_id": A, "email": "late@uni.edu", "_base_url": "http://h"}); t3 = r3["invite_link"].split("=")[1]
con = get_connection(); con.execute("UPDATE invitations SET expires_at='2000-01-01 00:00:00' WHERE email='late@uni.edu'"); con.commit(); con.close()
assert not ok(check_invitation({"token": t3}))
r4 = create_invitation({"admin_id": A, "email": "rev@uni.edu", "_base_url": "http://h"}); t4 = r4["invite_link"].split("=")[1]
iid = [i for i in list_invitations({"admin_id": A})["invitations"] if i["email"] == "rev@uni.edu"][0]["invitation_id"]
assert ok(revoke_invitation({"admin_id": A, "invitation_id": iid})) and not ok(check_invitation({"token": t4}))
print("ALL FEATURE CHECKS PASSED")
