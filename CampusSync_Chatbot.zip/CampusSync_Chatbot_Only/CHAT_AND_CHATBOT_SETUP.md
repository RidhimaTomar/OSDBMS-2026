# CampusSync — Faculty/Student Chat + FAQ Chatbot Only

This package contains the CampusSync project with faculty–student direct messaging and the built-in FAQ assistant, without the new appointment email notification logic.

## What it does
- Students can open **Chat & Assistant** and message faculty.
- Faculty can message students who have booked an appointment with them or already have a conversation.
- New messages create an in-app notification for the recipient.
- The CampusSync Assistant answers common questions about appointments, rescheduling/status, documents, calendar, notifications, and chat.

The assistant is a local rule-based FAQ bot, not a generative AI service; it does not require an API key or internet connection.

## Run
1. Extract the ZIP and open the `CampusSync_Chatbot_Only` folder in VS Code.
2. Open a terminal and run:
   ```powershell
   cd backend
   python server.py
   ```
3. Open `http://127.0.0.1:8000` and log in.
4. Select **Chat & Assistant** in the sidebar.

The chat feature uses the existing CampusSync user database and adds a `chat_messages` table automatically when the server initializes the database. This is a prototype; authentication/authorization should be hardened before production deployment.
