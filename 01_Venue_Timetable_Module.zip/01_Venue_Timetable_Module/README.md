# Module 1 — Venue and Timetable Management

Standalone Flask module for the OSDBMS-2026 project. It provides a small web frontend and SQLite backend.

## Features
- Add venues (admin).
- Select a venue for each booking and timetable class.
- Detect overlapping time ranges for the same venue across both bookings and timetable classes.
- Cancel a booking; only its creator or an admin can cancel it.
- View venue, booking, and timetable lists.
- JSON endpoints: `GET /api/venues`, `GET /api/availability`.

## Run on Windows
```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5001

## Demo login
Use the on-page demo sign-in with role `admin`, `faculty`, or `student`.
This is intentionally a demo identity selector. For integration, remove `/demo-login` and use the existing OSDBMS login to set `session["user_name"]` and `session["role"]`.

## Integration notes
- Merge the routes and schema into the existing backend rather than deploying a second app if your project already has a Flask server.
- The sample database file `venues.db` is created on first run.
- Store timestamps consistently in one timezone in production. The sample compares ISO local timestamps.
- Admin is allowed to create venues and timetable classes. Signed-in students/faculty can create bookings.
- This is a starter module. Add CSRF protection and production authentication before deployment.
