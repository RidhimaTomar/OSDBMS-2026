import os
import sqlite3
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import Flask, jsonify, render_template, request, session, redirect, url_for, flash

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "venues.db"

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "development-only-change-me")


def db():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS venues (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            venue_type TEXT NOT NULL,
            capacity INTEGER NOT NULL DEFAULT 0 CHECK(capacity >= 0),
            location TEXT NOT NULL DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            venue_id INTEGER NOT NULL REFERENCES venues(id),
            owner_name TEXT NOT NULL,
            owner_role TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'approved'
                CHECK(status IN ('pending','approved','cancelled')),
            CHECK(start_time < end_time)
        );
        CREATE TABLE IF NOT EXISTS timetable_classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            section TEXT NOT NULL,
            faculty TEXT NOT NULL,
            venue_id INTEGER NOT NULL REFERENCES venues(id),
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            CHECK(start_time < end_time)
        );
        CREATE INDEX IF NOT EXISTS idx_booking_venue_time
            ON bookings(venue_id, start_time, end_time, status);
        CREATE INDEX IF NOT EXISTS idx_class_venue_time
            ON timetable_classes(venue_id, start_time, end_time);
        """)
        count = con.execute("SELECT COUNT(*) FROM venues").fetchone()[0]
        if count == 0:
            con.executemany(
                "INSERT INTO venues(name, venue_type, capacity, location) VALUES(?,?,?,?)",
                [
                    ("Room 101", "Classroom", 60, "Block A"),
                    ("Computer Lab 1", "Laboratory", 40, "Block B"),
                    ("Seminar Hall", "Auditorium", 120, "Block C"),
                ],
            )


def logged_in(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_name") or session.get("role") not in ("admin", "faculty", "student"):
            flash("Please sign in first.", "error")
            return redirect(url_for("home"))
        return fn(*args, **kwargs)
    return wrapper


def admin_only(fn):
    @wraps(fn)
    @logged_in
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Only an admin can manage venues or timetable classes.", "error")
            return redirect(url_for("home"))
        return fn(*args, **kwargs)
    return wrapper


def parse_times(start_text, end_text):
    start = datetime.fromisoformat(start_text)
    end = datetime.fromisoformat(end_text)
    if end <= start:
        raise ValueError("End time must be after start time.")
    return start.isoformat(timespec="minutes"), end.isoformat(timespec="minutes")


def find_conflict(con, venue_id, start, end, exclude_booking=None):
    # A class conflicts with either a booking or another timetable class.
    booking_sql = """
        SELECT 'Booking' AS kind, title AS label, start_time, end_time
        FROM bookings
        WHERE venue_id = ? AND status IN ('pending','approved')
          AND start_time < ? AND end_time > ?
    """
    booking_params = [venue_id, end, start]
    if exclude_booking is not None:
        booking_sql += " AND id != ?"
        booking_params.append(exclude_booking)

    class_sql = """
        SELECT 'Timetable class' AS kind,
               subject || ' (' || section || ')' AS label,
               start_time, end_time
        FROM timetable_classes
        WHERE venue_id = ? AND start_time < ? AND end_time > ?
    """
    rows = con.execute(booking_sql, booking_params).fetchall()
    rows += con.execute(class_sql, [venue_id, end, start]).fetchall()
    return rows[0] if rows else None


@app.route("/", methods=["GET"])
def home():
    with db() as con:
        venues_rows = con.execute("SELECT * FROM venues WHERE active=1 ORDER BY name").fetchall()
        bookings = con.execute("""
            SELECT b.*, v.name AS venue_name FROM bookings b
            JOIN venues v ON v.id=b.venue_id
            ORDER BY b.start_time DESC LIMIT 100
        """).fetchall()
        classes = con.execute("""
            SELECT c.*, v.name AS venue_name FROM timetable_classes c
            JOIN venues v ON v.id=c.venue_id ORDER BY c.start_time LIMIT 100
        """).fetchall()
    return render_template("index.html", venues=venues_rows, bookings=bookings,
                           classes=classes, user=session.get("user_name"),
                           role=session.get("role"))


@app.post("/demo-login")
def demo_login():
    # Demo-only identity selector. Replace with the project's real authentication.
    name = request.form.get("user_name", "").strip()
    role = request.form.get("role", "").strip()
    if not name or role not in ("admin", "faculty", "student"):
        flash("Enter a name and choose a valid role.", "error")
    else:
        session["user_name"] = name[:80]
        session["role"] = role
        flash(f"Signed in as {name} ({role}).", "success")
    return redirect(url_for("home"))


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.post("/venues")
@admin_only
def add_venue():
    name = request.form.get("name", "").strip()
    venue_type = request.form.get("venue_type", "").strip()
    location = request.form.get("location", "").strip()
    try:
        capacity = int(request.form.get("capacity", "0"))
        if not name or not venue_type or capacity < 0:
            raise ValueError()
        with db() as con:
            con.execute(
                "INSERT INTO venues(name, venue_type, capacity, location) VALUES(?,?,?,?)",
                (name, venue_type, capacity, location),
            )
        flash("Venue added.", "success")
    except ValueError:
        flash("Enter a venue name, type and non-negative capacity.", "error")
    except sqlite3.IntegrityError:
        flash("A venue with that name already exists.", "error")
    return redirect(url_for("home"))


@app.post("/bookings")
@logged_in
def add_booking():
    title = request.form.get("title", "").strip()
    try:
        venue_id = int(request.form.get("venue_id", ""))
        start, end = parse_times(request.form["start_time"], request.form["end_time"])
        if not title:
            raise ValueError("Enter a booking title.")
        with db() as con:
            venue = con.execute("SELECT id FROM venues WHERE id=? AND active=1", (venue_id,)).fetchone()
            if not venue:
                raise ValueError("Choose an active venue.")
            conflict = find_conflict(con, venue_id, start, end)
            if conflict:
                raise ValueError(
                    f"Venue conflict: {conflict['kind']} '{conflict['label']}' "
                    f"already occupies an overlapping time."
                )
            con.execute("""
                INSERT INTO bookings(title, venue_id, owner_name, owner_role, start_time, end_time)
                VALUES(?,?,?,?,?,?)
            """, (title, venue_id, session["user_name"], session["role"], start, end))
        flash("Booking created without a venue conflict.", "success")
    except (ValueError, KeyError) as exc:
        flash(str(exc) or "Invalid booking details.", "error")
    return redirect(url_for("home"))


@app.post("/bookings/<int:booking_id>/cancel")
@logged_in
def cancel_booking(booking_id):
    with db() as con:
        row = con.execute("SELECT owner_name FROM bookings WHERE id=?", (booking_id,)).fetchone()
        if not row:
            flash("Booking not found.", "error")
        elif session["role"] != "admin" and row["owner_name"] != session["user_name"]:
            flash("You can cancel only your own bookings.", "error")
        else:
            con.execute("UPDATE bookings SET status='cancelled' WHERE id=?", (booking_id,))
            flash("Booking cancelled.", "success")
    return redirect(url_for("home"))


@app.post("/timetable")
@admin_only
def add_class():
    subject = request.form.get("subject", "").strip()
    section = request.form.get("section", "").strip()
    faculty = request.form.get("faculty", "").strip()
    try:
        venue_id = int(request.form.get("venue_id", ""))
        start, end = parse_times(request.form["start_time"], request.form["end_time"])
        if not subject or not section or not faculty:
            raise ValueError("Subject, section and faculty are required.")
        with db() as con:
            if not con.execute("SELECT id FROM venues WHERE id=? AND active=1", (venue_id,)).fetchone():
                raise ValueError("Choose an active venue.")
            conflict = find_conflict(con, venue_id, start, end)
            if conflict:
                raise ValueError(
                    f"Venue conflict: {conflict['kind']} '{conflict['label']}' "
                    f"already occupies an overlapping time."
                )
            con.execute("""
                INSERT INTO timetable_classes(subject, section, faculty, venue_id, start_time, end_time)
                VALUES(?,?,?,?,?,?)
            """, (subject, section, faculty, venue_id, start, end))
        flash("Timetable class added with venue.", "success")
    except (ValueError, KeyError) as exc:
        flash(str(exc) or "Invalid class details.", "error")
    return redirect(url_for("home"))


@app.post("/timetable/<int:class_id>/delete")
@admin_only
def delete_class(class_id):
    with db() as con:
        con.execute("DELETE FROM timetable_classes WHERE id=?", (class_id,))
    flash("Timetable class deleted.", "success")
    return redirect(url_for("home"))


@app.get("/api/venues")
def api_venues():
    with db() as con:
        rows = con.execute("SELECT id,name,venue_type,capacity,location FROM venues WHERE active=1 ORDER BY name").fetchall()
    return jsonify([dict(r) for r in rows])


@app.get("/api/availability")
@logged_in
def api_availability():
    try:
        venue_id = int(request.args["venue_id"])
        start, end = parse_times(request.args["start_time"], request.args["end_time"])
    except (KeyError, ValueError) as exc:
        return jsonify({"error": str(exc) or "Invalid time range"}), 400
    with db() as con:
        conflict = find_conflict(con, venue_id, start, end)
    return jsonify({"available": conflict is None,
                    "conflict": dict(conflict) if conflict else None})


if __name__ == "__main__":
    init_db()
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1", port=5001)
